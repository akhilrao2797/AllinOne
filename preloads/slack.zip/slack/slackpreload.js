const electron = require('electron')
const path = require('path');
window.onload = () => {
    function runcode(){
    document.querySelectorAll('div.ql-editor')[1].innerText='ssup people'
   
    }
    window.setTimeout(runcode,5000)
    
   }